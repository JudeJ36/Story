# Jude Johnson 4/11/23
# This program will write a short story based on user input

def main():

	storyTitle = input("Fairy tales or ghost stories?")

		if(storyTitle == "fairy tales"):
	
			start = "Once upon a time"
	
	mainGuy = input("Wizards or fairies?")
	
		if(mainGuy == "wizards"):
		
			startGuy =  "there was a land where wizards roamed freely."
			
		if(mainGuy == "fairies"):
		
			startGuy = "there once was a magical land where the fairies lived."
		
			
	
	if(storyTitle == "ghost stories"):
	
		start = "It was a dark and gloomy night"
		
	
		
	